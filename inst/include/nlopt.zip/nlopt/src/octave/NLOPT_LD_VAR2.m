% NLOPT_LD_VAR2: Limited-memory variable-metric, rank 2 (local, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_VAR2
  val = 14;
