% NLOPT_LN_AUGLAG_EQ: Augmented Lagrangian method for equality constraints (local, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LN_AUGLAG_EQ
  val = 32;
