% NLOPT_GN_ISRES: ISRES evolutionary constrained optimization (global, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_ISRES
  val = 35;
